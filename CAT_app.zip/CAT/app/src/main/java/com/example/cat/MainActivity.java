package com.example.cat;

import android.Manifest;
import android.app.SearchManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.graphics.drawable.Drawable;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import android.provider.Settings;
import java.util.ArrayList;
import android.content.Context;
import android.widget.Toast;
import java.util.Objects;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.VIBRATE;

public class MainActivity extends AppCompatActivity {

    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private TextView textView;

    private ImageView imageView;
    private Intent intent;
    private AudioManager audioManager;
    private SensorManager mSensorManager;
    private float mAccel;
    private float mAccelCurrent;
    private float mAccelLast;
    int brightness;
    Context context;
    Vibrator vibrator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageView);

        imageView.setImageResource(R.drawable.appiconpres__1_);

        context = getApplicationContext();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Objects.requireNonNull(mSensorManager).registerListener(mSensorListener, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
        mAccel = 10f;
        mAccelCurrent = SensorManager.GRAVITY_EARTH;
        mAccelLast = SensorManager.GRAVITY_EARTH;

        System.out.println(Settings.System.canWrite(context));
        if(!Settings.System.canWrite(context)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS));
        }

        ActivityCompat.requestPermissions(this, new String[]{RECORD_AUDIO}, PackageManager.PERMISSION_GRANTED);

        textView = findViewById(R.id.textView);
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
            }
        });

        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {

            @Override
            public void onReadyForSpeech(Bundle bundle) {

            }

            @Override
            public void onBeginningOfSpeech() {

            }

            @Override
            public void onRmsChanged(float v) {

            }

            @Override
            public void onBufferReceived(byte[] bytes) {

            }

            @Override
            public void onEndOfSpeech() {

            }

            @Override
            public void onError(int error) {
                //vibrator.vibrate(500);
                //textToSpeech.speak("Error, please try again.", TextToSpeech.QUEUE_FLUSH, null, null);
            }
            @Override
            public void onResults(Bundle results) {
                imageView.setImageResource(R.drawable.appiconpres__1_);
                ArrayList<String> matches = results.getStringArrayList(speechRecognizer.RESULTS_RECOGNITION);
                String string = "";
                textView.setText("");
                if (matches != null) {
                    string = matches.get(0).toLowerCase();
                    textView.setText(string);
                    if (!string.contains("cancel") || !string.contains("stop")) {
                        // increase brightness
                        if (string.contains("too dark")) {
                            increaseBrightness();
                        }
                        else if (string.contains("brighter")) {
                            increaseBrightness();
                        }
                        else if (string.contains("can't see")) {
                            increaseBrightness();
                        }
                        else if ((string.contains("increase") || (string.contains("higher")) || string.contains("up")) && string.contains("brightness")) {
                            increaseBrightness();
                        }
                        // decrease brightness
                        else if (string.contains("darker")) {
                            decreaseBrightness();
                        }
                        else if (string.contains("hurt") && ((string.contains("eye")) || string.contains("look"))) {
                            decreaseBrightness();
                        }
                        else if (string.contains("too bright")) {
                            decreaseBrightness();
                        }
                        else if (string.contains("dimmer")) {
                            decreaseBrightness();
                        }
                        else if (string.contains("too much light")) {
                            decreaseBrightness();
                        }

                        else if ((string.contains("decrease") || (string.contains("lower")) || string.contains("down")) && string.contains("brightness")) {
                            decreaseBrightness();
                        }

                        // increase volume
                        else if (string.contains("too quiet")) {
                            increaseVolume();
                        }
                        else if (string.contains("louder")) {
                            increaseVolume();
                        }
                        else if (string.contains("can't hear")) {
                            increaseVolume();
                        }
                        else if (string.contains("volume up")) {
                            increaseVolume();
                        }

                        //decrease volume
                        else if (string.contains("quieter")) {
                            decreaseVolume();
                        }
                        else if (string.contains("too loud")) {
                            decreaseVolume();
                        }
                        else if (string.contains("hurt") && string.contains("ear")) {
                            decreaseVolume();
                        }
                        else if (string.contains("volume down")) {
                            decreaseVolume();
                        }

                        // time
                        else if (string.contains("what time is it") || string.contains("what's the time")) {
                            getTime();
                        }
                        else if (string.contains("what is the time")) {
                            getTime();
                        }
                        else if (string.contains("current time")) {
                            getTime();
                        }
                        else if (string.equals("time")) {
                            getTime();
                        }

                        //date
                        else if (string.contains("what day is it") || string.contains("what's the date")) {
                            getDate();
                        }
                        else if (string.contains("current date")) {
                            getDate();
                        }
                        else if (string.equals("date")) {
                            getDate();
                        }

                        //home screen <3
                        else if (string.equals("home")) {
                            goHome();
                        }
                        else if(string.contains("home screen")){
                            goHome();
                        }
                        else if(string.contains("main screen")){
                            goHome();
                        }

                        // font increase
                        else if(string.contains("can't read"))
                        {
                            biggerText();
                        }
                        else if ((string.contains("text")||string.contains("words")||string.contains("font")) && string.contains("too") && (string.contains("small")|| string.contains("bigger")))
                        {
                            biggerText();
                        }
                        else if (string.contains("increase font")||string.contains("zoom out")){
                            biggerText();
                        }

                        // font decrease
                        else if ((string.contains("text")||string.contains("words")||string.contains("font")) && string.contains("too") && (string.contains("big")|| string.contains("smaller")))
                        {
                            smallerText();
                        }
                        else if (string.contains("decrease font")||string.contains("zoom in")){
                            smallerText();
                        }
                        else if((string.contains("open")||string.contains("go"))){
                            // apps available:
                            if(string.contains("phone") || string.contains("contact") || string.contains("message")){
                                Intent intent = new Intent(Intent.ACTION_MAIN);
                                intent.addCategory(Intent.CATEGORY_APP_CONTACTS);
                                startActivity(intent);
                            }
                            else if(string.contains("settings") || string.contains("options")){
                                Intent intent = new Intent(Settings.ACTION_SETTINGS);
                                startActivity(intent);
                            }
                            else if(string.contains("picture") || string.contains("photo") || string.contains("gallery")){
                                Intent intent = new Intent(Intent.ACTION_MAIN);
                                intent.addCategory(Intent.CATEGORY_APP_GALLERY);
                                startActivity(intent);
                            }
                            else {
                                webSearch(string);
                            }
                        }
                        else if (string.contains("call") || string.contains("text") || string.contains("message")){
                            Intent intent = new Intent(Intent.ACTION_MAIN);
                            intent.addCategory(Intent.CATEGORY_APP_CONTACTS);
                            startActivity(intent);
                        }
                        else
                        {
                            webSearch(string);
                        }

                    }
                }
            }

            @Override
            public void onPartialResults(Bundle bundle) {

            }

            @Override
            public void onEvent(int i, Bundle bundle) {

            }

        });
    }
    private final SensorEventListener mSensorListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            mAccelLast = mAccelCurrent;
            mAccelCurrent = (float) Math.sqrt((double) (x * x + y * y + z * z));
            float delta = mAccelCurrent - mAccelLast;
            mAccel = mAccel * 0.9f + delta;
            if (mAccel > 12) {
                vibrator.vibrate(500);

                textToSpeech.speak("Listening", TextToSpeech.QUEUE_FLUSH, null, null);
                imageView.setImageResource(R.drawable.openeyesappicon);

                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                speechRecognizer.startListening(intent);
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };
    @Override
    protected void onResume() {
        mSensorManager.registerListener(mSensorListener, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }
    @Override
    protected void onPause() {
        mSensorManager.unregisterListener(mSensorListener);
        super.onPause();
    }
    public void increaseBrightness(){
        brightness =
                Settings.System.getInt(context.getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS, 0);

        if(brightness + 51 <= 255) {
            Settings.System.putInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, brightness + 51);
        } else {
            Settings.System.putInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, 255);
            textToSpeech.speak("Maximum brightness reached", TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }
    public void decreaseBrightness(){
        brightness =
                Settings.System.getInt(context.getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS, 0);
        if(brightness - 51 >= 0) {
            Settings.System.putInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, brightness - 51);
        } else {
            Settings.System.putInt(context.getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS, 0);
            textToSpeech.speak("Minimum brightness reached", TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }
    public void increaseVolume(){
        int volume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        if(volume + 2 <= 15) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume + 2, AudioManager.FLAG_SHOW_UI);
        } else {
            textToSpeech.speak("Maximum volume reached", TextToSpeech.QUEUE_FLUSH, null, null);
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 15, AudioManager.FLAG_SHOW_UI);
        }
    }
    public void decreaseVolume(){
        int volume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        if(volume - 2 >= 0) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume - 2, AudioManager.FLAG_SHOW_UI);
        } else {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI);
            vibrator.vibrate(500);
        }
    }
    public void getTime(){
        SimpleDateFormat sdf = new SimpleDateFormat("h:mm a");
        textToSpeech.speak(sdf.format(new Date()), TextToSpeech.QUEUE_FLUSH, null, null);
    }
    public void getDate(){
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE L d yyyy");
        textToSpeech.speak(sdf.format(new Date()), TextToSpeech.QUEUE_FLUSH, null, null);
    }
    public void goHome(){
        startActivity((new Intent(Intent.ACTION_MAIN)).addCategory(Intent.CATEGORY_HOME).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
    public void biggerText(){
        float curSize = Settings.System.getFloat(getBaseContext().getContentResolver(),
                Settings.System.FONT_SCALE, (float) 0);

        Settings.System.putFloat(getBaseContext().getContentResolver(),
                Settings.System.FONT_SCALE, curSize + (float) 0.25);
    }
    public void smallerText(){
        float curSize = Settings.System.getFloat(getBaseContext().getContentResolver(),
                Settings.System.FONT_SCALE, (float) 0);

        Settings.System.putFloat(getBaseContext().getContentResolver(),
                Settings.System.FONT_SCALE, curSize - (float) 0.25);
    }
    public void webSearch(String str) {
        Intent viewSearch = new Intent(Intent.ACTION_WEB_SEARCH);
        viewSearch.putExtra(SearchManager.QUERY, str);
        startActivity(viewSearch);
    }
}


